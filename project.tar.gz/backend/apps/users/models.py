from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models
from django.db.models import Q
from django.db.models.functions import Lower
from django.utils import timezone
import secrets
import uuid


def _generate_referral_code() -> str:
    """Generate a short unique referral code (8 chars, URL-safe)."""
    return secrets.token_urlsafe(6)[:8]


class UserManager(BaseUserManager):
    def create_user(self, phone=None, password=None, **extra_fields):
        if not phone or not str(phone).strip():
            raise ValueError("Номер телефона обязателен.")
        phone = str(phone).strip()
        user = self.model(phone=phone, **extra_fields)
        if not user.referral_code:
            user.referral_code = _generate_referral_code()
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, phone, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        return self.create_user(phone=phone, password=password, **extra_fields)


class User(AbstractBaseUser, PermissionsMixin):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    phone = models.CharField(max_length=20, unique=True)
    username = models.CharField(max_length=30, null=True, blank=True, db_index=True)
    telegram_id = models.BigIntegerField(unique=True, null=True, blank=True, db_index=True)
    telegram_username = models.CharField(max_length=255, blank=True)
    display_name = models.CharField(max_length=255, blank=True)
    avatar = models.ImageField(upload_to="avatars/", blank=True, null=True)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    date_joined = models.DateTimeField(auto_now_add=True)

    # --- Stars (virtual currency) ---
    stars = models.PositiveIntegerField(
        default=0,
        help_text="Баланс звёзд пользователя",
    )

    # --- Online status ---
    last_seen = models.DateTimeField(
        null=True, blank=True,
        help_text="Последний раз в сети",
    )
    show_last_seen = models.BooleanField(
        default=True,
        help_text="Показывать другим время последнего захода",
    )
    show_phone = models.BooleanField(
        default=True,
        help_text="Показывать другим номер телефона",
    )

    # --- Privacy: who can write DMs ---
    DM_PRIVACY_EVERYONE = "everyone"
    DM_PRIVACY_NOBODY = "nobody"
    DM_PRIVACY_CHOICES = [
        (DM_PRIVACY_EVERYONE, "Все"),
        (DM_PRIVACY_NOBODY, "Никто"),
    ]
    dm_privacy = models.CharField(
        max_length=10,
        choices=DM_PRIVACY_CHOICES,
        default=DM_PRIVACY_EVERYONE,
        help_text="Кто может писать в личные сообщения",
    )

    # --- Privacy: who can add to groups ---
    ADD_TO_GROUP_EVERYONE = "everyone"
    ADD_TO_GROUP_NOBODY = "nobody"
    ADD_TO_GROUP_CHOICES = [
        (ADD_TO_GROUP_EVERYONE, "Все"),
        (ADD_TO_GROUP_NOBODY, "Никто"),
    ]
    add_to_group_privacy = models.CharField(
        max_length=10,
        choices=ADD_TO_GROUP_CHOICES,
        default=ADD_TO_GROUP_EVERYONE,
        help_text="Кто может добавлять в группы",
    )

    # --- Referral system ---
    referral_code = models.CharField(
        max_length=10, unique=True, blank=True, db_index=True,
        help_text="Уникальный реферальный код пользователя",
    )
    referred_by = models.ForeignKey(
        "self", null=True, blank=True, on_delete=models.SET_NULL,
        related_name="referrals",
        help_text="Кто привёл этого пользователя",
    )

    USERNAME_FIELD = "phone"
    REQUIRED_FIELDS = []

    objects = UserManager()

    def get_avatar_url(self, request=None, base_url: str | None = None):
        """Первая аватарка из галереи или legacy User.avatar. Возвращает защищённый URL с HMAC-токеном."""
        from django.conf import settings as django_settings
        from apps.files.protected_media import make_protected_media_url

        base = base_url or (getattr(django_settings, "FRONTEND_URL", "") or "").rstrip("/")
        try:
            first = self.avatars.order_by("order").first()
            if first and first.image:
                path = first.image.name
                return make_protected_media_url(path, request, base_url=base or None)
            if self.avatar:
                path = self.avatar.name
                return make_protected_media_url(path, request, base_url=base or None)
        except (ValueError, OSError):
            pass  # missing file
        return None

    def save(self, *args, **kwargs):
        if not self.referral_code:
            self.referral_code = _generate_referral_code()
        if self.username is not None:
            self.username = (self.username.strip() or None)
            if self.username:
                self.username = self.username.lower()
        super().save(*args, **kwargs)

    class Meta:
        verbose_name = "User"
        verbose_name_plural = "Users"
        constraints = [
            models.UniqueConstraint(
                Lower("username"),
                condition=Q(username__isnull=False),
                name="users_username_unique_ci",
            )
        ]



class UserSession(models.Model):
    """Tracks an authenticated session (one per login). Used for session listing,
    revocation (logout), and new-login notifications."""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="sessions")
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(blank=True, default="")
    device_label = models.CharField(max_length=200, blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)
    last_active = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True, db_index=True)

    class Meta:
        ordering = ["-last_active"]

    def __str__(self):
        return f"Session {self.id} ({self.device_label or 'unknown'}) for {self.user_id}"


class UserAvatar(models.Model):
    """Галерея аватарок пользователя (до 30 шт.)."""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="avatars")
    image = models.ImageField(upload_to="user_avatars/")
    order = models.PositiveSmallIntegerField(default=0)

    class Meta:
        ordering = ["order", "id"]
